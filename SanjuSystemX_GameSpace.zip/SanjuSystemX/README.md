# SanjuSystemX — Game Space (Shizuku)

Package `com.sanju.systemx` · Kotlin · minSdk 26 · targetSdk 35 · no root.

## Build
- **Android Studio:** open this folder → sync → Run (or Build > Build APK).
- **GitHub Actions:** push; `.github/workflows/build.yml` produces the debug APK artifact.
- **CLI:** `gradle assembleDebug` (Gradle 8.9, JDK 17) → `app/build/outputs/apk/debug/app-debug.apk`

## Use
1. Install and start **Shizuku** (wireless debugging), then open Game Space → *Grant permission*.
2. Allow *Display over other apps* for the floating panel / color filter; grant DND access for DND.
3. Optional artwork: add your own licensed `res/drawable-nodpi/itachi_art.png`.
