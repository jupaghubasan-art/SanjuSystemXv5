# Feature table (status: NOT yet tested on a Vivo Y05 — code was written without an Android SDK/device)

| Feature | Method | Permission | No root | Tested on device | Known limits |
|---|---|---|---|---|---|
| 4.5 s intro | Canvas + ValueAnimator, tap to skip, toggle in Settings | – | yes | No | Procedural art only; add own image for Itachi portrait |
| Ambient background | Canvas loop, Full/Low/Off, stops in onStop | – | yes | No | – |
| Launch MLBB | PackageManager launch intent | – | yes | No | Checks 4 known package names |
| Floating panel | TYPE_APPLICATION_OVERLAY in foreground service | Overlay, notifications | yes | No | OriginOS may need "background pop-ups"/autostart allowed |
| FPS (MLBB) | `dumpsys SurfaceFlinger --latency` on MLBB layer | Shizuku | needs Shizuku | No | Unavailable if layer isn't found; Unity layer naming varies |
| Hz read | Display.refreshRate | – | yes | No | Panel rate, not game FPS |
| Hz set | `settings put system peak/min_refresh_rate`, verified by re-read | Shizuku | needs Shizuku | No | OriginOS may override; result is reported honestly |
| CPU freq | /sys scaling_cur_freq | – | yes | No | Often blocked → "Unavailable" |
| CPU usage | /proc/stat | Shizuku | needs Shizuku | No | – |
| GPU load | /sys/kernel/ged/hal/gpu_utilization | Shizuku | needs Shizuku | No | MediaTek-only, format unverified |
| Temp / thermal | Battery sensor, PowerManager thermal status | – | yes | No | Battery temp only |
| RAM, ping | ActivityManager, TCP connect | Internet | yes | No | – |
| Performance modes | `cmd game mode <mode> <pkg>` + refresh policy | Shizuku | needs Shizuku | No | Effect depends on OriginOS Game Mode support |
| Touch presets | system long_press_timeout | Shizuku | needs Shizuku | No | NOT touch sampling rate |
| Color filter | Non-touchable tint/dim overlay | Overlay | yes | No | No saturation/contrast; UI-level only |
| Grayscale | Color-correction secure setting | Shizuku | needs Shizuku | No | System-wide |
| DND | NotificationManager.setInterruptionFilter | DND access | yes | No | System rules still apply |
| MLBB FPS cap 30–120 | — | — | — | — | Unsupported (set in MLBB) |
| Vulkan, resolution, angle | — | — | — | — | Unsupported (set in MLBB) |
| Screenshot/recording shortcuts, network boost, RAM cleaner | — | — | — | — | Not included: no verified legitimate effect |
