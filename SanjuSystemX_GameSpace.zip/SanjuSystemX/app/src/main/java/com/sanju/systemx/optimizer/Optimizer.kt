package com.sanju.systemx.optimizer

import android.app.NotificationManager
import android.content.Context
import android.os.Handler
import android.os.Looper
import com.sanju.systemx.gaming.GameScanner
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge
import java.util.concurrent.Executors

object Optimizer {
    data class Res(val name: String, val ok: Boolean, val detail: String)
    enum class Mode(val label: String, val gm: String) {
        BATTERY("Battery Saver", "battery"), BALANCED("Balanced", "standard"), PERFORMANCE("Performance", "performance")
    }

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    /** Runs [work] off the main thread and delivers the results on the main thread. */
    fun async(work: () -> List<Res>, cb: (List<Res>) -> Unit) = io.execute {
        val r = try { work() } catch (t: Throwable) { listOf(Res("Error", false, t.message ?: "failed")) }
        main.post { cb(r) }
    }

    private val bad = Regex("(?i)error|exception|unknown|invalid|not found|usage")

    fun applyMode(ctx: Context, m: Mode): List<Res> {
        Prefs.mode = m.ordinal
        if (!ShizukuBridge.ready()) return listOf(Res("Shizuku", false, "Not ready — selection saved, but NO system change was made"))
        val out = ArrayList<Res>()
        val pkg = GameScanner.pkg
        if (pkg == null) out += Res("Game mode", false, "MLBB not installed")
        else {
            val r = ShizukuBridge.exec("cmd game mode ${m.gm} $pkg")
            val fail = !r.ok || bad.containsMatchIn(r.text)
            out += Res("Android Game Mode → ${m.gm}", !fail,
                if (r.text.isBlank()) "Accepted by system (how much it changes is up to Android/OriginOS)" else r.text.take(140))
        }
        out += when (m) {
            Mode.BATTERY -> DisplayCtl.set(ctx, 60)
            Mode.BALANCED -> DisplayCtl.restore(ctx)
            Mode.PERFORMANCE -> DisplayCtl.set(ctx, DisplayCtl.supported(ctx).max())
        }
        return out
    }

    /** SLOW = 600 ms, FAST = 250 ms system long-press delay; DEFAULT restores. This is NOT the panel's touch sampling rate. */
    fun setTouch(preset: String): Res {
        if (!ShizukuBridge.ready()) return Res("Touch $preset", false, "Needs Shizuku")
        Prefs.setS("touch", preset)
        if (preset == "DEFAULT") return Res("Touch DEFAULT", Sys.restore("secure", "long_press_timeout"), "System long-press delay restored")
        val v = if (preset == "FAST") "250" else "600"
        val r = Sys.put("secure", "long_press_timeout", v)
        val ok = r.ok && Sys.verify("secure", "long_press_timeout", v)
        return Res("Touch $preset", ok, if (ok) "Long-press delay ${v} ms (system setting; physical touch sampling is unchanged)" else r.text)
    }

    fun setGrayscale(on: Boolean): Res {
        if (!ShizukuBridge.ready()) return Res("Grayscale", false, "Needs Shizuku")
        if (!on) {
            val a = Sys.restore("secure", "accessibility_display_daltonizer_enabled"); val b = Sys.restore("secure", "accessibility_display_daltonizer")
            return Res("Grayscale off", a && b, "System color correction restored")
        }
        val a = Sys.put("secure", "accessibility_display_daltonizer", "0")
        val b = Sys.put("secure", "accessibility_display_daltonizer_enabled", "1")
        val ok = b.ok && Sys.verify("secure", "accessibility_display_daltonizer_enabled", "1")
        return Res("Grayscale", ok, if (ok) "System-wide monochrome filter on (affects every app)" else a.text + b.text)
    }

    fun dndAccess(ctx: Context) = ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    fun setDnd(ctx: Context, name: String): Res {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) return Res("DND $name", false, "Do Not Disturb access not granted")
        if (!Prefs.has("snap_dnd")) Prefs.setI("snap_dnd", nm.currentInterruptionFilter)
        val f = when (name) {
            "Gaming" -> NotificationManager.INTERRUPTION_FILTER_PRIORITY
            "Standard" -> NotificationManager.INTERRUPTION_FILTER_ALL
            "Sleep" -> NotificationManager.INTERRUPTION_FILTER_ALARMS
            else -> NotificationManager.INTERRUPTION_FILTER_NONE
        }
        nm.setInterruptionFilter(f)
        val ok = nm.currentInterruptionFilter == f
        return Res("DND $name", ok, if (ok) "Applied. Alarms/priority contacts follow your system DND rules" else "System did not accept the change")
    }

    fun restoreDnd(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (Prefs.has("snap_dnd") && nm.isNotificationPolicyAccessGranted) { nm.setInterruptionFilter(Prefs.i("snap_dnd", 1)); Prefs.remove("snap_dnd") }
    }

    fun restoreAll(ctx: Context): List<Res> {
        val out = ArrayList<Res>()
        restoreDnd(ctx); out += Res("DND", true, "Restored to previous state")
        if (!ShizukuBridge.ready()) { out += Res("System settings", false, "Shizuku not ready — nothing changed by this app could be reverted"); return out }
        GameScanner.pkg?.let { out += Res("Game mode → standard", ShizukuBridge.exec("cmd game mode standard $it").ok, "") }
        out += DisplayCtl.restore(ctx)
        out += setTouch("DEFAULT")
        out += setGrayscale(false)
        Prefs.mode = 1
        return out
    }
}
