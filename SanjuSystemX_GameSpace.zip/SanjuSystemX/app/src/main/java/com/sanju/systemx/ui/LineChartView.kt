package com.sanju.systemx.ui

import android.content.Context
import android.graphics.*
import android.view.View

class LineChartView(c: Context) : View(c) {
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.RED; strokeWidth = 3f; style = Paint.Style.STROKE }
    private val grid = Paint().apply { color = 0x22FFFFFF; strokeWidth = 1f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.DIM; textSize = 22f }
    private var data: List<Float> = emptyList()
    var ceiling = 130f

    fun set(d: Collection<Float>) { data = d.toList(); invalidate() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        for (v in listOf(30f, 60f, 90f, 120f)) {
            val y = h - h * v / ceiling
            c.drawLine(0f, y, w, y, grid); c.drawText(v.toInt().toString(), 4f, y - 4f, txt)
        }
        if (data.size < 2) { c.drawText("No FPS samples yet", w / 3, h / 2, txt); return }
        val p = Path()
        data.forEachIndexed { i, v ->
            val x = w * i / (data.size - 1); val y = h - h * v.coerceIn(0f, ceiling) / ceiling
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        c.drawPath(p, line)
    }
}
