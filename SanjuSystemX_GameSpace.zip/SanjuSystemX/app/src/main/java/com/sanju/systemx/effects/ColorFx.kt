package com.sanju.systemx.effects

import android.graphics.Color
import com.sanju.systemx.settings.Prefs

/**
 * Color effects are a translucent, non-touchable overlay (tint + dim) drawn above the game.
 * It changes what you SEE; it cannot change MLBB's rendering. Saturation/contrast cannot be done this way
 * (shown as unsupported). Grayscale uses a system-wide filter via Shizuku (see Optimizer.setGrayscale).
 */
object ColorFx {
    val presets = listOf("Natural", "Cool", "Warm", "Cinematic", "Custom")

    fun apply(name: String) {
        Prefs.setS("fx_preset", name)
        when (name) {
            "Natural" -> set(0, 0, 0)
            "Cool" -> set(-70, 80, 0)
            "Warm" -> set(70, 80, 0)
            "Cinematic" -> set(40, 70, 12)
        }
    }
    private fun set(t: Int, i: Int, d: Int) { Prefs.setI("fx_temp", t); Prefs.setI("fx_int", i); Prefs.setI("fx_dim", d) }

    val temp get() = Prefs.i("fx_temp", 0)
    val intensity get() = Prefs.i("fx_int", 50)
    val dim get() = Prefs.i("fx_dim", 0)
    val preset get() = Prefs.s("fx_preset", "Natural") ?: "Natural"

    fun tintColor(): Int {
        val t = temp
        val a = (intensity / 100f * Math.abs(t) / 100f * 90f).toInt()
        return if (t >= 0) Color.argb(a, 255, 150, 60) else Color.argb(a, 60, 120, 255)
    }
    fun dimColor(): Int = Color.argb((dim / 100f * 255f).toInt(), 0, 0, 0)

    fun reset() { set(0, 0, 0); Prefs.setS("fx_preset", "Natural"); Prefs.tintOn = false }
}
