package com.sanju.systemx.shizuku

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuBridge {
    enum class State { NOT_RUNNING, NO_PERMISSION, READY }
    data class Out(val code: Int, val text: String) { val ok get() = code == 0 }

    fun state(): State = try {
        when {
            !Shizuku.pingBinder() -> State.NOT_RUNNING
            Shizuku.isPreV11() -> State.NOT_RUNNING
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> State.READY
            else -> State.NO_PERMISSION
        }
    } catch (t: Throwable) { State.NOT_RUNNING }

    fun ready() = state() == State.READY

    fun request(code: Int = 7001) {
        try { Shizuku.requestPermission(code) } catch (_: Throwable) {}
    }

    // Shizuku 13 made newProcess() private; reflection is the commonly used workaround for simple shell commands.
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).apply { isAccessible = true }
    }

    /** Blocking. Never call from the main thread. stderr is merged into stdout. */
    fun exec(cmd: String): Out = try {
        if (!ready()) Out(-2, "Shizuku not ready")
        else {
            val p = newProcess.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
            val text = p.inputStream.bufferedReader().readText().trim()
            Out(p.waitFor(), text)
        }
    } catch (t: Throwable) { Out(-1, t.cause?.message ?: t.message ?: "exec failed") }

    fun getSetting(ns: String, key: String) = exec("settings get $ns $key").text
    fun putSetting(ns: String, key: String, v: String) = exec("settings put $ns $key $v")
}
