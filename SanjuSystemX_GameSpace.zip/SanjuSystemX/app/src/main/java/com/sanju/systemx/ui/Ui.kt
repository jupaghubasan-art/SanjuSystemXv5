package com.sanju.systemx.ui

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

object Ui {
    val BG = 0xFF0B0D14.toInt()
    val CARD = 0xDD141824.toInt()
    val RED = 0xFFE0243A.toInt()
    val BLUE = 0xFF3B82F6.toInt()
    val TEXT = 0xFFECEFF4.toInt()
    val DIM = 0xFF8B93A7.toInt()
    val GREEN = 0xFF22C55E.toInt()
    val AMBER = 0xFFF59E0B.toInt()

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun round(c: Context, fill: Int, r: Int = 12, stroke: Int = 0, strokeColor: Int = 0) =
        GradientDrawable().apply {
            setColor(fill); cornerRadius = dp(c, r).toFloat()
            if (stroke > 0) setStroke(dp(c, stroke), strokeColor)
        }

    fun text(c: Context, s: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false) =
        TextView(c).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun card(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        val p = dp(c, 12); setPadding(p, p, p, p)
        background = round(c, CARD, 14, 1, 0x33E0243A)
    }

    fun row(c: Context) = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

    fun lp(w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f, m: Int = 0, c: Context? = null): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(w, h, weight)
        if (m != 0 && c != null) { val d = dp(c, m); lp.setMargins(d, d, d, d) }
        return lp
    }

    fun button(c: Context, label: String, selected: Boolean = false, enabled: Boolean = true, onClick: () -> Unit): TextView =
        TextView(c).apply {
            text = label; textSize = 13f; gravity = Gravity.CENTER
            val h = dp(c, 14); val v = dp(c, 9); setPadding(h, v, h, v)
            minHeight = dp(c, 40)
            setSel(this, selected, enabled)
            isEnabled = enabled
            setOnClickListener { onClick() }
        }

    fun setSel(t: TextView, sel: Boolean, enabled: Boolean = true) {
        val c = t.context
        t.setTextColor(if (enabled) TEXT else DIM)
        t.background = round(c, if (!enabled) 0x22FFFFFF else if (sel) 0xFF7A1424.toInt() else 0x33FFFFFF, 10,
            if (sel) 2 else 1, if (sel) BLUE else 0x22FFFFFF)
    }

    fun toggle(c: Context, title: String, sub: String?, checked: Boolean, enabled: Boolean = true, cb: (Boolean) -> Unit): View =
        row(c).apply {
            setPadding(0, dp(c, 6), 0, dp(c, 6))
            val col = LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                addView(text(c, title, 14f, if (enabled) TEXT else DIM, true))
                if (sub != null) addView(text(c, sub, 11f, DIM))
            }
            addView(col, lp(0, weight = 1f))
            addView(Switch(c).apply { isChecked = checked; isEnabled = enabled; setOnCheckedChangeListener { _, v -> cb(v) } })
        }

    fun slider(c: Context, title: String, min: Int, max: Int, value: Int, onChange: (Int) -> Unit): View =
        LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            val label = text(c, "$title: $value", 12f, DIM)
            addView(label)
            addView(SeekBar(c).apply {
                this.max = max - min; progress = value - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { label.text = "$title: ${p + min}"; if (u) onChange(p + min) }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }

    fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_SHORT).show()
}
