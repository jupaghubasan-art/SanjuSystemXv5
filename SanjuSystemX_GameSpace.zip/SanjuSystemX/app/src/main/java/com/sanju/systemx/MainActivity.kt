package com.sanju.systemx

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import com.sanju.systemx.gaming.GameScanner
import com.sanju.systemx.monitor.Monitor
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.ui.BgView
import com.sanju.systemx.ui.IntroView
import com.sanju.systemx.ui.Ui
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var bg: BgView
    private lateinit var shell: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var screens: Screens
    private val navViews = LinkedHashMap<String, android.widget.TextView>()
    var current = "Home"; private set

    private val snapL: (Monitor.Snap) -> Unit = { screens.onSnap(it) }
    private val binderL = Shizuku.OnBinderReceivedListener { runOnUiThread { nav(current) } }
    private val deadL = Shizuku.OnBinderDeadListener { runOnUiThread { nav(current) } }
    private val permL = Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { nav(current) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        GameScanner.detect(this)
        screens = Screens(this)
        root = FrameLayout(this).apply { setBackgroundColor(Ui.BG) }
        bg = BgView(this)
        root.addView(bg, FrameLayout.LayoutParams(-1, -1))

        shell = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val side = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = Ui.dp(this@MainActivity, 8); setPadding(p, p, p, p)
            setBackgroundColor(0xAA0B0D14.toInt())
            addView(Ui.text(this@MainActivity, "GAME", 18f, Ui.TEXT, true))
            addView(Ui.text(this@MainActivity, "SPACE", 18f, Ui.RED, true))
            addView(Ui.text(this@MainActivity, "Sanju", 11f, Ui.DIM))
        }
        for (n in listOf("Home", "Performance", "Graphics", "Effects", "Tools", "Settings")) {
            val t = Ui.button(this, n) { nav(n) }
            navViews[n] = t
            side.addView(t, Ui.lp(m = 3, c = this))
        }
        shell.addView(side, Ui.lp(Ui.dp(this, 150), -1))
        content = FrameLayout(this)
        shell.addView(content, Ui.lp(0, -1, 1f))
        root.addView(shell, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        nav("Home")

        if (Prefs.intro && b == null) {
            shell.visibility = View.INVISIBLE
            root.addView(IntroView(this) {
                root.removeViewAt(root.childCount - 1)
                shell.visibility = View.VISIBLE
            }, FrameLayout.LayoutParams(-1, -1))
        }
        try {
            Shizuku.addBinderReceivedListenerSticky(binderL); Shizuku.addBinderDeadListener(deadL)
            Shizuku.addRequestPermissionResultListener(permL)
        } catch (_: Throwable) {}
    }

    fun nav(name: String) {
        current = name
        navViews.forEach { (k, v) -> Ui.setSel(v, k == name) }
        content.removeAllViews()
        val pad = Ui.dp(this, 12)
        val sv = ScrollView(this).apply { setPadding(pad, pad, pad, pad); clipToPadding = false }
        sv.addView(screens.build(name), FrameLayout.LayoutParams(-1, -2))
        content.addView(sv, FrameLayout.LayoutParams(-1, -1))
    }

    override fun onStart() {
        super.onStart(); bg.start()
        GameScanner.detect(this)
        Monitor.subscribe(this, snapL)
        nav(current)
    }
    override fun onStop() { Monitor.unsubscribe(snapL); bg.stop(); super.onStop() }
    override fun onDestroy() {
        try { Shizuku.removeBinderReceivedListener(binderL); Shizuku.removeBinderDeadListener(deadL); Shizuku.removeRequestPermissionResultListener(permL) } catch (_: Throwable) {}
        super.onDestroy()
    }
}
