package com.sanju.systemx.gaming

import android.content.Context
import android.content.Intent

object GameScanner {
    private val known = listOf("com.mobile.legends", "com.mobiin.gp", "com.mobilelegends.hwag", "com.vng.mlbbvn")
    var pkg: String? = null
        private set

    fun detect(ctx: Context): String? {
        pkg = known.firstOrNull {
            try { ctx.packageManager.getPackageInfo(it, 0); true } catch (_: Exception) { false }
        }
        return pkg
    }

    fun launch(ctx: Context): Boolean {
        val p = pkg ?: detect(ctx) ?: return false
        val i = ctx.packageManager.getLaunchIntentForPackage(p) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return true
    }
}
