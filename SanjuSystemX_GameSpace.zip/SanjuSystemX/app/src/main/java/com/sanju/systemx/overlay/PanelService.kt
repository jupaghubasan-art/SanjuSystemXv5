package com.sanju.systemx.overlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.ServiceCompat
import com.sanju.systemx.effects.ColorFx
import com.sanju.systemx.monitor.Monitor
import com.sanju.systemx.optimizer.Optimizer
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.ui.Ui

/** Foreground service hosting the floating panel (bubble <-> expanded) and the color tint overlay. */
class PanelService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var tint: View? = null
    private var fpsT: TextView? = null; private var hzT: TextView? = null; private var tempT: TextView? = null
    private var modeBtn: TextView? = null

    private val snapL: (Monitor.Snap) -> Unit = { s ->
        fpsT?.text = s.fps?.toString() ?: "—"
        hzT?.text = s.hz.toInt().toString()
        tempT?.text = s.tempC?.let { "%.0f°C".format(it) } ?: "—"
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        Prefs.init(this)
        wm = getSystemService(WindowManager::class.java)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("panel", "Game panel", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "panel").setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Game Space overlay active").setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0)
        sync()
        return START_NOT_STICKY
    }

    private fun sync() {
        val can = Settings.canDrawOverlays(this)
        if (can && Prefs.tintOn) showTint() else hideTint()
        if (can && Prefs.panelOn) { if (panel == null && bubble == null) showBubble() } else { hidePanel(); hideBubble() }
        if (!(can && (Prefs.tintOn || Prefs.panelOn))) stopSelf()
    }

    private fun lp(w: Int, h: Int, touchable: Boolean) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = Prefs.i("panelX", 40); y = Prefs.i("panelY", 120) }

    private fun showTint() {
        val v = tint ?: object : View(this) {
            override fun onDraw(c: Canvas) { c.drawColor(ColorFx.tintColor()); c.drawColor(ColorFx.dimColor()) }
        }.also { tint = it; wm.addView(it, lp(-1, -1, false).apply { x = 0; y = 0 }) }
        v.invalidate()
    }
    private fun hideTint() { tint?.let { try { wm.removeView(it) } catch (_: Exception) {} }; tint = null }

    private fun drag(handle: View, target: () -> View?, params: WindowManager.LayoutParams, onTap: (() -> Unit)?) {
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = params.x; sy = params.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 8 || Math.abs(e.rawY - dy) > 8) moved = true
                    if (moved) { params.x = sx + (e.rawX - dx).toInt(); params.y = sy + (e.rawY - dy).toInt(); target()?.let { wm.updateViewLayout(it, params) } }
                }
                MotionEvent.ACTION_UP -> { if (moved) { Prefs.setI("panelX", params.x); Prefs.setI("panelY", params.y) } else onTap?.invoke() }
            }
            true
        }
    }

    private fun showBubble() {
        hidePanel()
        val v = TextView(this).apply {
            text = "S"; textSize = 18f; setTextColor(Ui.TEXT); gravity = Gravity.CENTER
            background = Ui.round(this@PanelService, 0xFFB5162B.toInt(), 22, 2, Ui.BLUE)
            alpha = Prefs.opacity / 100f
        }
        val p = lp(Ui.dp(this, 44), Ui.dp(this, 44), true)
        wm.addView(v, p); bubble = v
        drag(v, { bubble }, p) { showPanel() }
    }
    private fun hideBubble() { bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble = null }

    private fun showPanel() {
        hideBubble()
        val c = this
        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            val pd = Ui.dp(c, 10); setPadding(pd, pd, pd, pd)
            background = Ui.round(c, 0xEE0E1119.toInt(), 14, 1, 0x88E0243A.toInt())
            alpha = Prefs.opacity / 100f
        }
        val p = lp(Ui.dp(c, 250), WindowManager.LayoutParams.WRAP_CONTENT, true)
        val head = Ui.row(c).apply {
            addView(Ui.text(c, "SANJU GAME PANEL", 12f, Ui.TEXT, true), Ui.lp(0, weight = 1f))
            addView(Ui.text(c, "—", 18f, Ui.DIM).apply { setPadding(Ui.dp(c, 12), 0, Ui.dp(c, 4), 0); setOnClickListener { showBubble() } })
        }
        root.addView(head)
        drag(head.getChildAt(0), { panel }, p, null)
        fun stat(label: String): TextView {
            val t = Ui.text(c, "—", 18f, Ui.TEXT, true)
            root.findViewWithTag<LinearLayout>("stats")?.addView(LinearLayout(c).apply {
                orientation = LinearLayout.VERTICAL
                addView(Ui.text(c, label, 10f, Ui.DIM)); addView(t)
            }, Ui.lp(0, weight = 1f))
            return t
        }
        root.addView(LinearLayout(c).apply { tag = "stats"; setPadding(0, Ui.dp(c, 6), 0, Ui.dp(c, 6)) })
        fpsT = stat("FPS"); hzT = stat("HZ"); tempT = stat("TEMP")

        modeBtn = Ui.button(c, "Mode: ${Optimizer.Mode.values()[Prefs.mode].label}") {
            val next = Optimizer.Mode.values()[(Prefs.mode + 1) % 3]
            modeBtn?.text = "Mode: ${next.label} …"
            Optimizer.async({ Optimizer.applyMode(c, next) }) { r ->
                modeBtn?.text = "Mode: ${next.label}" + if (r.all { it.ok }) " ✔" else " ✘"
                Ui.toast(c, r.joinToString("\n") { (if (it.ok) "✔ " else "✘ ") + it.name })
            }
        }
        root.addView(modeBtn, Ui.lp(m = 2, c = c))
        root.addView(Ui.toggle(c, "Touch Boost", "Fast long-press delay (Shizuku)", Prefs.s("touch", "DEFAULT") == "FAST") { on ->
            Optimizer.async({ listOf(Optimizer.setTouch(if (on) "FAST" else "DEFAULT")) }) { Ui.toast(c, it[0].detail) }
        })
        root.addView(Ui.toggle(c, "Game Filter", "Tint overlay (see Effects)", Prefs.tintOn) { on -> Prefs.tintOn = on; sync() })
        root.addView(Ui.toggle(c, "Block Notif", "Do Not Disturb: Gaming", Optimizer.dndAccess(c) && Prefs.has("snap_dnd")) { on ->
            val r = if (on) Optimizer.setDnd(c, "Gaming") else { Optimizer.restoreDnd(c); Optimizer.Res("DND", true, "Restored") }
            Ui.toast(c, r.detail)
        })
        wm.addView(root, p); panel = root
        Monitor.subscribe(this, snapL)
    }
    private fun hidePanel() {
        Monitor.unsubscribe(snapL)
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null
    }

    override fun onDestroy() { hidePanel(); hideBubble(); hideTint(); super.onDestroy() }

    companion object {
        /** Re-evaluate what should be on screen (call after changing panelOn / tintOn / fx values). */
        fun sync(ctx: Context) {
            val i = Intent(ctx, PanelService::class.java)
            if (Prefs.panelOn || Prefs.tintOn) ctx.startForegroundService(i) else ctx.stopService(i)
        }
    }
}
