package com.sanju.systemx.resolution

import android.content.Context
import android.hardware.display.DisplayManager
import com.sanju.systemx.optimizer.Optimizer.Res
import com.sanju.systemx.optimizer.Sys
import kotlin.math.abs
import kotlin.math.roundToInt

/** Refresh-rate control. Only modes reported by the display are offered; every change is verified by re-reading the display. */
object DisplayCtl {
    fun supported(ctx: Context): List<Int> =
        ctx.getSystemService(DisplayManager::class.java).getDisplay(0).supportedModes
            .map { it.refreshRate.roundToInt() }.distinct().sorted()

    fun current(ctx: Context): Int = ctx.getSystemService(DisplayManager::class.java).getDisplay(0).refreshRate.roundToInt()

    /** Blocking (sleeps ~1.5 s to verify). Call off the main thread. */
    fun set(ctx: Context, hz: Int): Res {
        if (hz !in supported(ctx)) return Res("Refresh $hz Hz", false, "Not supported by this display (${supported(ctx).joinToString("/")} Hz)")
        val a = Sys.put("system", "peak_refresh_rate", hz.toString())
        val b = Sys.put("system", "min_refresh_rate", hz.toString())
        if (!a.ok && !b.ok) return Res("Refresh $hz Hz", false, "Settings write failed: ${a.text}")
        Thread.sleep(1500)
        val now = current(ctx)
        return if (abs(now - hz) <= 1) Res("Refresh $hz Hz", true, "Display reports $now Hz")
        else Res("Refresh $hz Hz", false, "Requested $hz, display reports $now Hz — OriginOS/system overrode the request (adaptive refresh or app-specific policy)")
    }

    fun restore(ctx: Context): Res {
        val a = Sys.restore("system", "peak_refresh_rate"); val b = Sys.restore("system", "min_refresh_rate")
        return Res("Refresh rate restore", a && b, "System refresh policy back to previous values")
    }
}
