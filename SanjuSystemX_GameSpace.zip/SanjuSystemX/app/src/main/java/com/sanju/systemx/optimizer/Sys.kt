package com.sanju.systemx.optimizer

import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge

/** Settings writes that remember the original value so everything can be restored. Blocking. */
object Sys {
    private fun k(ns: String, key: String) = "snap_${ns}_$key"

    fun put(ns: String, key: String, v: String): ShizukuBridge.Out {
        if (!Prefs.has(k(ns, key))) Prefs.setS(k(ns, key), ShizukuBridge.getSetting(ns, key))
        return ShizukuBridge.putSetting(ns, key, v)
    }

    fun verify(ns: String, key: String, v: String) = ShizukuBridge.getSetting(ns, key) == v

    fun restore(ns: String, key: String): Boolean {
        if (!Prefs.has(k(ns, key))) return true
        val old = Prefs.s(k(ns, key), "null")
        val r = if (old == null || old == "null") ShizukuBridge.exec("settings delete $ns $key")
        else ShizukuBridge.putSetting(ns, key, old)
        if (r.ok) Prefs.remove(k(ns, key))
        return r.ok
    }
}
