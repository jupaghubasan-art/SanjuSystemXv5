package com.sanju.systemx.settings

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("sx", 0) }

    fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    fun setB(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    fun i(k: String, d: Int) = sp.getInt(k, d)
    fun setI(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    fun s(k: String, d: String?) = sp.getString(k, d)
    fun setS(k: String, v: String?) = sp.edit().putString(k, v).apply()
    fun has(k: String) = sp.contains(k)
    fun remove(k: String) = sp.edit().remove(k).apply()
    fun clearAll() = sp.edit().clear().apply()

    var intro: Boolean get() = b("intro", true); set(v) = setB("intro", v)
    /** 0 = full, 1 = low (reduced fps), 2 = off */
    var animMode: Int get() = i("animMode", 1); set(v) = setI("animMode", v)
    var panelOn: Boolean get() = b("panelOn", false); set(v) = setB("panelOn", v)
    var tintOn: Boolean get() = b("tintOn", false); set(v) = setB("tintOn", v)
    var opacity: Int get() = i("opacity", 90); set(v) = setI("opacity", v)
    var mode: Int get() = i("mode", 1); set(v) = setI("mode", v)
}
