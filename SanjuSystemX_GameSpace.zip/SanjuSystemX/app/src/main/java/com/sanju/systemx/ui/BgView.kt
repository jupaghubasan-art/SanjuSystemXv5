package com.sanju.systemx.ui

import android.content.Context
import android.graphics.Canvas
import android.os.SystemClock
import android.view.View
import com.sanju.systemx.settings.Prefs

/** Optional ambient background. Runs only between start() and stop(); 0 = full, 1 = low fps, 2 = off. */
class BgView(ctx: Context) : View(ctx) {
    private val scene = ItachiScene(ctx)
    private val t0 = SystemClock.uptimeMillis()
    private var running = false
    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postDelayed(this, if (Prefs.animMode == 0) 33L else 100L)
        }
    }

    fun start() { stop(); if (Prefs.animMode != 2) { running = true; post(tick) } else invalidate() }
    fun stop() { running = false; removeCallbacks(tick) }
    override fun onDetachedFromWindow() { stop(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        if (Prefs.animMode == 2) { c.drawColor(Ui.BG); return }
        scene.draw(c, width.toFloat(), height.toFloat(), (SystemClock.uptimeMillis() - t0) / 1000f, 1f)
        c.drawColor(0x99000000.toInt()) // keep UI readable
    }
}
