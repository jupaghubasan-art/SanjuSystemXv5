package com.sanju.systemx

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.sanju.systemx.effects.ColorFx
import com.sanju.systemx.gaming.GameScanner
import com.sanju.systemx.monitor.Monitor
import com.sanju.systemx.optimizer.Optimizer
import com.sanju.systemx.optimizer.Optimizer.Res
import com.sanju.systemx.overlay.PanelService
import com.sanju.systemx.resolution.DisplayCtl
import com.sanju.systemx.settings.Prefs
import com.sanju.systemx.shizuku.ShizukuBridge
import com.sanju.systemx.ui.LineChartView
import com.sanju.systemx.ui.Ui

class Screens(private val a: MainActivity) {
    private val stats = HashMap<String, TextView>()
    private var chart: LineChartView? = null
    private var detail: TextView? = null

    private fun col() = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
    private fun h(s: String) = Ui.text(a, s, 16f, Ui.TEXT, true).apply { setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 6)) }
    private fun note(s: String) = Ui.text(a, s, 11f, Ui.DIM).apply { setPadding(0, Ui.dp(a, 2), 0, Ui.dp(a, 6)) }
    private fun gap(v: View) = v.also { (it.layoutParams as? LinearLayout.LayoutParams)?.setMargins(0, 0, 0, 0) }

    private fun chip(label: String): View {
        val v = Ui.text(a, "—", 17f, Ui.TEXT, true); stats[label] = v
        return LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            val p = Ui.dp(a, 8); setPadding(p, p, p, p)
            background = Ui.round(a, Ui.CARD, 10, 1, 0x22FFFFFF)
            addView(Ui.text(a, label, 10f, Ui.DIM)); addView(v)
        }
    }
    private fun statRow(vararg l: String) = Ui.row(a).apply { l.forEach { addView(chip(it), Ui.lp(0, weight = 1f, m = 3, c = a)) } }

    private fun log() = Ui.text(a, "", 12f, Ui.DIM).also { it.setPadding(0, Ui.dp(a, 6), 0, 0) }
    private fun show(tv: TextView, r: List<Res>) {
        tv.text = r.joinToString("\n") { (if (it.ok) "✔ " else "✘ ") + it.name + (if (it.detail.isNotBlank()) " — ${it.detail}" else "") }
        tv.setTextColor(if (r.all { it.ok }) Ui.GREEN else Ui.AMBER)
    }

    fun onSnap(s: Monitor.Snap) {
        stats["FPS"]?.text = s.fps?.toString() ?: "—"
        stats["HZ"]?.text = s.hz.toInt().toString()
        stats["TEMP"]?.text = s.tempC?.let { "%.1f°C".format(it) } ?: "Unavailable"
        stats["CPU"]?.text = s.cpuPct?.let { "$it%" } ?: "Unavailable"
        stats["GPU"]?.text = s.gpuPct?.let { "$it%" } ?: "Unavailable"
        stats["RAM"]?.text = "${s.ramUsedMb}/${s.ramTotalMb} MB"
        chart?.set(Monitor.history)
        detail?.text = buildString {
            appendLine("FPS source: ${s.fpsNote}")
            appendLine("FPS session min/avg/max: ${if (Monitor.fpsMin == Int.MAX_VALUE) "—" else Monitor.fpsMin} / ${Monitor.fpsAvg() ?: "—"} / ${if (Monitor.fpsMax == 0) "—" else Monitor.fpsMax}")
            appendLine("Display refresh (panel Hz, not game FPS): ${"%.0f".format(s.hz)} Hz")
            appendLine("CPU freq (max core): ${s.cpuMhz?.let { "$it MHz" } ?: "Unavailable (blocked by Android)"}")
            appendLine("CPU usage: ${s.cpuPct?.let { "$it% (/proc/stat via Shizuku)" } ?: "Unavailable (needs Shizuku)"}")
            appendLine("GPU load: ${s.gpuPct?.let { "$it% (ged/gpu_utilization, MediaTek only)" } ?: "Unavailable (not exposed on this device)"}")
            appendLine("Temp: ${s.tempC?.let { "%.1f°C battery sensor (only temperature apps may read)".format(it) } ?: "Unavailable"}; max this session ${"%.1f".format(Monitor.tempMax)}°C")
            appendLine("Thermal status: ${s.thermal}")
            appendLine("RAM available: ${s.ramAvailMb} MB")
            append("Ping (TCP to 1.1.1.1:443): ${s.pingMs?.let { "$it ms" } ?: "Unavailable"}")
        }
    }

    fun build(name: String): View { stats.clear(); chart = null; detail = null
        return when (name) { "Performance" -> performance(); "Graphics" -> graphics(); "Effects" -> effects(); "Tools" -> tools(); "Settings" -> settings(); else -> home() }
    }

    // ---------------------------------------------------------------- Home
    private fun home(): View = col().apply {
        addView(statRow("FPS", "HZ", "TEMP", "CPU", "GPU", "RAM"))
        Monitor.last?.let { onSnap(it) }
        val row = Ui.row(a)
        // MLBB card
        val g = Ui.card(a).apply {
            addView(h("Mobile Legends: Bang Bang"))
            val pkg = GameScanner.pkg
            addView(note(if (pkg != null) "Installed: $pkg" else "MLBB not found on this phone"))
            addView(Ui.button(a, "LAUNCH GAME", pkg != null, pkg != null) {
                if (!GameScanner.launch(a)) Ui.toast(a, "Could not launch MLBB")
            })
        }
        // Shizuku card
        val st = ShizukuBridge.state()
        val z = Ui.card(a).apply {
            addView(h("Shizuku"))
            addView(Ui.text(a, when (st) {
                ShizukuBridge.State.READY -> "● Connected — system controls enabled"
                ShizukuBridge.State.NO_PERMISSION -> "● Running — permission needed"
                else -> "● Not running — SHIZUKU REQUIRED for boost, Hz, touch, FPS"
            }, 12f, if (st == ShizukuBridge.State.READY) Ui.GREEN else Ui.AMBER))
            if (st == ShizukuBridge.State.NO_PERMISSION) addView(Ui.button(a, "Grant permission") { ShizukuBridge.request() }, Ui.lp(m = 3, c = a))
            if (st == ShizukuBridge.State.NOT_RUNNING) addView(Ui.button(a, "Open Shizuku app") {
                val i = a.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (i != null) a.startActivity(i) else Ui.toast(a, "Shizuku is not installed")
            }, Ui.lp(m = 3, c = a))
        }
        row.addView(g, Ui.lp(0, weight = 1f, m = 4, c = a)); row.addView(z, Ui.lp(0, weight = 1f, m = 4, c = a))
        addView(row)
        // Performance mode
        val out = log()
        addView(Ui.card(a).apply {
            addView(h("Performance mode"))
            addView(note("Sets Android Game Mode for MLBB + display refresh policy. Results below show what the system accepted."))
            val r = Ui.row(a); val btns = ArrayList<TextView>()
            Optimizer.Mode.values().forEach { m ->
                val b = Ui.button(a, m.label, Prefs.mode == m.ordinal, ShizukuBridge.ready()) {
                    btns.forEachIndexed { i, t -> Ui.setSel(t, i == m.ordinal) }
                    out.text = "Applying…"
                    Optimizer.async({ Optimizer.applyMode(a, m) }) { show(out, it) }
                }
                btns.add(b); r.addView(b, Ui.lp(0, weight = 1f, m = 3, c = a))
            }
            addView(r); addView(out)
            addView(Ui.button(a, "Restore all changes made by this app") { out.text = "Restoring…"; Optimizer.async({ Optimizer.restoreAll(a) }) { show(out, it) } }, Ui.lp(m = 3, c = a))
        }, Ui.lp(m = 4, c = a))
        addView(Ui.card(a).apply {
            addView(h("Floating panel"))
            addView(Ui.toggle(a, "Show floating panel over game", "Draggable bubble → expandable panel", Prefs.panelOn) { on -> setPanel(on) })
        }, Ui.lp(m = 4, c = a))
    }

    private fun setPanel(on: Boolean) {
        if (on && !Settings.canDrawOverlays(a)) {
            Ui.toast(a, "Allow “Display over other apps” for Game Space, then enable again")
            a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}"))); a.nav("Home"); return
        }
        if (on && android.os.Build.VERSION.SDK_INT >= 33) a.requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        Prefs.panelOn = on; PanelService.sync(a)
    }

    // ---------------------------------------------------------------- Performance
    private fun performance(): View = col().apply {
        addView(statRow("FPS", "HZ", "TEMP", "CPU", "GPU", "RAM"))
        addView(Ui.card(a).apply {
            addView(h("FPS history (MLBB)"))
            val c = LineChartView(a); chart = c; c.set(Monitor.history)
            addView(c, Ui.lp(h = Ui.dp(a, 150)))
            val d = note(""); d.textSize = 12f; detail = d; addView(d)
            Monitor.last?.let { onSnap(it) }
            addView(Ui.button(a, "Reset session stats") { Monitor.resetSession(); a.nav("Performance") })
        }, Ui.lp(m = 4, c = a))
        addView(note("Polling runs only while this screen or the expanded floating panel is visible. Measure before/after yourself with the same match settings — this app makes no fixed performance claim."))
    }

    // ---------------------------------------------------------------- Graphics
    private fun graphics(): View = col().apply {
        val out = log()
        val sup = DisplayCtl.supported(a)
        addView(Ui.card(a).apply {
            addView(h("Display refresh rate"))
            addView(note("Current: ${DisplayCtl.current(a)} Hz · Supported: ${sup.joinToString(" / ")} Hz. This is the panel's rate, not MLBB's FPS."))
            val r = Ui.row(a)
            listOf(60, 90, 120).forEach { hz ->
                val ok = hz in sup && ShizukuBridge.ready()
                r.addView(Ui.button(a, if (hz in sup) "$hz Hz" else "$hz Hz ✕", DisplayCtl.current(a) == hz, ok) {
                    out.text = "Requesting $hz Hz…"; Optimizer.async({ listOf(DisplayCtl.set(a, hz)) }) { show(out, it) }
                }, Ui.lp(0, weight = 1f, m = 3, c = a))
            }
            addView(r); addView(out)
            if (!ShizukuBridge.ready()) addView(note("SHIZUKU REQUIRED to change refresh rate."))
            addView(Ui.button(a, "Restore system refresh policy") { Optimizer.async({ listOf(DisplayCtl.restore(a)) }) { show(out, it) } }, Ui.lp(m = 3, c = a))
        }, Ui.lp(m = 4, c = a))
        addView(Ui.card(a).apply {
            addView(h("MLBB FPS cap"))
            val r = Ui.row(a)
            listOf(30, 45, 60, 90, 120).forEach { r.addView(Ui.button(a, "$it", false, false) {}, Ui.lp(0, weight = 1f, m = 3, c = a)) }
            addView(r)
            addView(note("Unsupported: MLBB's frame-rate cap lives inside the game (Settings → Graphics → Frame Rate). Android gives no legitimate external control, and this app never patches or injects into MLBB. The live FPS shown elsewhere is MEASURED, not set."))
            addView(note("Vulkan / graphics API, resolution scaling and camera angle: Unsupported on this device — set them in MLBB's own settings."))
        }, Ui.lp(m = 4, c = a))
    }

    // ---------------------------------------------------------------- Effects
    private fun effects(): View = col().apply {
        val out = log()
        fun push() { PanelService.sync(a) }
        addView(Ui.card(a).apply {
            addView(h("Game color filter (overlay)"))
            addView(note("Draws a see-through tint/dim layer above the game (touches pass through). It changes what you see, not MLBB's rendering. Saturation, contrast and Vivid can't be done this way: unsupported."))
            addView(Ui.toggle(a, "Enable filter", null, Prefs.tintOn) { on ->
                if (on && !Settings.canDrawOverlays(a)) { setPanel(true); return@toggle }
                Prefs.tintOn = on; push()
            })
            val r = Ui.row(a)
            ColorFx.presets.forEach { p ->
                r.addView(Ui.button(a, p, ColorFx.preset == p) { ColorFx.apply(p); push(); a.nav("Effects") }, Ui.lp(0, weight = 1f, m = 2, c = a))
            }
            addView(r)
            addView(Ui.slider(a, "Color temperature (−cool / +warm)", -100, 100, ColorFx.temp) { Prefs.setI("fx_temp", it); Prefs.setS("fx_preset", "Custom"); push() })
            addView(Ui.slider(a, "Filter intensity", 0, 100, ColorFx.intensity) { Prefs.setI("fx_int", it); Prefs.setS("fx_preset", "Custom"); push() })
            addView(Ui.slider(a, "Brightness dim", 0, 50, ColorFx.dim) { Prefs.setI("fx_dim", it); Prefs.setS("fx_preset", "Custom"); push() })
            addView(Ui.button(a, "Reset to default") { ColorFx.reset(); push(); a.nav("Effects") }, Ui.lp(m = 3, c = a))
        }, Ui.lp(m = 4, c = a))
        addView(Ui.card(a).apply {
            addView(h("Grayscale (system-wide, Shizuku)"))
            addView(note("Uses Android's color-correction setting; affects the whole screen and every app until turned off."))
            addView(Ui.toggle(a, "Grayscale", null, false, ShizukuBridge.ready()) { on -> Optimizer.async({ listOf(Optimizer.setGrayscale(on)) }) { show(out, it) } })
            addView(out)
        }, Ui.lp(m = 4, c = a))
    }

    // ---------------------------------------------------------------- Tools
    private fun tools(): View = col().apply {
        val out = log()
        addView(Ui.card(a).apply {
            addView(h("Touch response"))
            addView(note("Changes Android's system long-press delay (SLOW 600 ms / DEFAULT / FAST 250 ms). It does NOT raise the screen's physical touch sampling rate. For manufacturer touch options use OriginOS Settings / iManager Game Mode."))
            val r = Ui.row(a); val cur = Prefs.s("touch", "DEFAULT")
            listOf("SLOW", "DEFAULT", "FAST").forEach { p ->
                r.addView(Ui.button(a, p, cur == p, ShizukuBridge.ready()) { Optimizer.async({ listOf(Optimizer.setTouch(p)) }) { show(out, it); a.nav("Tools") } }, Ui.lp(0, weight = 1f, m = 3, c = a))
            }
            addView(r)
            if (!ShizukuBridge.ready()) addView(note("SHIZUKU REQUIRED."))
        }, Ui.lp(m = 4, c = a))
        addView(Ui.card(a).apply {
            addView(h("Do Not Disturb"))
            if (!Optimizer.dndAccess(a)) {
                addView(note("Needs Do Not Disturb access (Android permission)."))
                addView(Ui.button(a, "Grant DND access") { a.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) })
            } else {
                addView(note("Gaming = priority only · Standard = all · Sleep = alarms only · Custom = block all. Calls/alarms allowed by your system DND rules can still come through."))
                val r = Ui.row(a)
                listOf("Gaming", "Standard", "Sleep", "Custom").forEach { n ->
                    r.addView(Ui.button(a, n) { show(out, listOf(Optimizer.setDnd(a, n))) }, Ui.lp(0, weight = 1f, m = 2, c = a))
                }
                addView(r)
            }
            addView(out)
        }, Ui.lp(m = 4, c = a))
        addView(Ui.card(a).apply {
            addView(h("Session summary"))
            val fmt = { v: Int, bad: Int -> if (v == bad) "—" else v.toString() }
            addView(Ui.text(a, "FPS min/avg/max: ${fmt(Monitor.fpsMin, Int.MAX_VALUE)} / ${Monitor.fpsAvg() ?: "—"} / ${fmt(Monitor.fpsMax, 0)}\nMax temperature: ${if (Monitor.tempMax > 0) "%.1f°C".format(Monitor.tempMax) else "—"}", 13f))
            addView(Ui.button(a, "Reset session") { Monitor.resetSession(); a.nav("Tools") }, Ui.lp(m = 3, c = a))
        }, Ui.lp(m = 4, c = a))
    }

    // ---------------------------------------------------------------- Settings
    private fun settings(): View = col().apply {
        val out = log()
        addView(Ui.card(a).apply {
            addView(h("General"))
            addView(Ui.toggle(a, "Opening animation", "~4.5 s, tap to skip", Prefs.intro) { Prefs.intro = it })
            addView(note("Animated background"))
            val r = Ui.row(a); val names = listOf("Full", "Low power", "Off")
            names.forEachIndexed { i, n -> r.addView(Ui.button(a, n, Prefs.animMode == i) { Prefs.animMode = i; a.nav("Settings") }, Ui.lp(0, weight = 1f, m = 2, c = a)) }
            addView(r)
            addView(Ui.slider(a, "Floating panel opacity %", 40, 100, Prefs.opacity) { Prefs.opacity = it })
            addView(note("Optional art: put your own licensed image at res/drawable-nodpi/itachi_art.png and rebuild."))
        }, Ui.lp(m = 4, c = a))
        addView(Ui.card(a).apply {
            addView(h("Permissions"))
            addView(Ui.text(a, "Overlay: ${if (Settings.canDrawOverlays(a)) "granted" else "not granted"}\nDND access: ${if (Optimizer.dndAccess(a)) "granted" else "not granted"}\nShizuku: ${ShizukuBridge.state()}", 12f, Ui.DIM))
            addView(Ui.button(a, "Overlay permission") { a.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${a.packageName}"))) }, Ui.lp(m = 3, c = a))
            addView(Ui.button(a, "Reset everything this app changed") { Optimizer.async({ ColorFx.reset(); PanelService.sync(a); Prefs.panelOn = false; Optimizer.restoreAll(a) }) { show(out, it) } }, Ui.lp(m = 3, c = a))
            addView(out)
        }, Ui.lp(m = 4, c = a))
        addView(Ui.card(a).apply {
            addView(h("Privacy"))
            addView(note("No account, no analytics. Settings stay on this phone. The only network use is a TCP connect to 1.1.1.1:443 for the ping reading. Shizuku is used only for the shell commands shown in each result log."))
        }, Ui.lp(m = 4, c = a))
    }
}
