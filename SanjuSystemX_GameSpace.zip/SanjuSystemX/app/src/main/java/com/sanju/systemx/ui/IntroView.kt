package com.sanju.systemx.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View

/** ~4.5 s opening sequence. Tap anywhere to skip. Animator is cancelled on detach. */
class IntroView(ctx: Context, private val onEnd: () -> Unit) : View(ctx) {
    private val scene = ItachiScene(ctx)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var prog = 0f
    private var done = false
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 4500
        addUpdateListener { prog = it.animatedValue as Float; invalidate(); if (prog >= 1f) finish() }
    }

    init { isClickable = true; setOnClickListener { finish() } }

    private fun finish() { if (done) return; done = true; anim.cancel(); onEnd() }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!done) anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        scene.draw(c, w, h, prog * 4.5f, prog)
        val la = ((prog - .6f) / .15f).coerceIn(0f, 1f)
        p.reset(); p.isAntiAlias = true; p.textAlign = Paint.Align.CENTER
        p.color = Color.argb((255 * la).toInt(), 236, 239, 244); p.textSize = h * .07f; p.letterSpacing = .35f
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.ITALIC)
        c.drawText("GAME SPACE", w / 2, h * .78f, p)
        p.textSize = h * .035f; p.letterSpacing = 0f; p.color = Color.argb((200 * la).toInt(), 160, 165, 180)
        c.drawText("Optimizing your game experience…", w / 2, h * .84f, p)
        val bw = w * .4f; val x0 = (w - bw) / 2; val y = h * .88f
        p.color = 0x33FFFFFF; c.drawRect(x0, y, x0 + bw, y + 4f, p)
        p.color = Ui.RED; c.drawRect(x0, y, x0 + bw * prog, y + 4f, p)
        p.textAlign = Paint.Align.RIGHT; p.textSize = h * .03f; p.color = Color.argb(160, 160, 165, 180)
        c.drawText("Tap to skip", w - 24f, h - 20f, p)
    }
}
