package com.sanju.systemx.monitor

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import com.sanju.systemx.gaming.GameScanner
import com.sanju.systemx.shizuku.ShizukuBridge
import java.io.File
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Executors

/**
 * One shared poller. It only runs while at least one listener is subscribed
 * (visible screen or expanded floating panel), so it costs nothing in the background.
 */
object Monitor {
    data class Snap(
        val fps: Int?, val fpsNote: String, val hz: Float,
        val tempC: Float?, val thermal: String,
        val cpuPct: Int?, val cpuMhz: Int?, val gpuPct: Int?,
        val ramUsedMb: Long, val ramAvailMb: Long, val ramTotalMb: Long,
        val pingMs: Int?
    )

    var last: Snap? = null; private set
    val history = ArrayDeque<Float>()
    var fpsMin = Int.MAX_VALUE; private set
    var fpsMax = 0; private set
    var tempMax = 0f; private set
    private var fpsSum = 0L
    private var fpsN = 0
    fun fpsAvg(): Int? = if (fpsN == 0) null else (fpsSum / fpsN).toInt()
    fun resetSession() { fpsMin = Int.MAX_VALUE; fpsMax = 0; fpsSum = 0; fpsN = 0; tempMax = 0f; history.clear() }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val listeners = ArrayList<(Snap) -> Unit>()
    private var app: Context? = null
    private var scheduled = false
    private var busy = false
    private var tick = 0
    private var layer: String? = null
    private var prevTotal = 0L
    private var prevIdle = 0L
    private var ping: Int? = null
    var intervalMs = 2000L

    fun subscribe(ctx: Context, l: (Snap) -> Unit) {
        app = ctx.applicationContext
        if (!listeners.contains(l)) listeners.add(l)
        schedule(0)
    }
    fun unsubscribe(l: (Snap) -> Unit) { listeners.remove(l) }

    private fun schedule(d: Long) { if (!scheduled) { scheduled = true; main.postDelayed(tickR, d) } }

    private val tickR = Runnable {
        scheduled = false
        if (listeners.isEmpty() || busy) return@Runnable
        busy = true
        io.execute {
            val s = try { sample() } catch (_: Throwable) { null }
            main.post {
                busy = false
                if (s != null) { last = s; record(s); listeners.toList().forEach { it(s) } }
                if (listeners.isNotEmpty()) schedule(intervalMs)
            }
        }
    }

    private fun record(s: Snap) {
        s.fps?.let {
            fpsMin = minOf(fpsMin, it); fpsMax = maxOf(fpsMax, it); fpsSum += it; fpsN++
            history.addLast(it.toFloat()); while (history.size > 90) history.removeFirst()
        }
        s.tempC?.let { tempMax = maxOf(tempMax, it) }
    }

    private fun sample(): Snap {
        val c = app!!
        tick++
        val mi = ActivityManager.MemoryInfo()
        c.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val hz = c.getSystemService(DisplayManager::class.java).getDisplay(0).refreshRate
        val bi = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)?.takeIf { it > 0 }?.div(10f)
        val thermal = when (c.getSystemService(PowerManager::class.java).currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "Normal"
            PowerManager.THERMAL_STATUS_LIGHT -> "Light"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
            PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
            else -> "Unknown"
        }
        val mhz = (0 until 8).mapNotNull {
            try { File("/sys/devices/system/cpu/cpu$it/cpufreq/scaling_cur_freq").readText().trim().toLongOrNull() } catch (_: Exception) { null }
        }.maxOrNull()?.div(1000)?.toInt()

        var cpu: Int? = null; var gpu: Int? = null; var fps: Int? = null
        var note = "Needs Shizuku"
        if (ShizukuBridge.ready()) {
            val pkg = GameScanner.pkg
            if (pkg == null) note = "MLBB not installed"
            else {
                if ((layer == null && tick % 5 == 0) || tick % 15 == 0) layer = findLayer(pkg)
                val l = layer
                val script = "echo '##CPU';head -n1 /proc/stat;echo '##GPU';cat /sys/kernel/ged/hal/gpu_utilization 2>/dev/null;" +
                    (if (l != null && !l.contains('\'')) "echo '##FPS';dumpsys SurfaceFlinger --latency '$l'" else "")
                val out = ShizukuBridge.exec(script).text
                val sec = HashMap<String, MutableList<String>>()
                var cur = ""
                for (line in out.lines()) {
                    if (line.startsWith("##")) { cur = line.substring(2); sec[cur] = ArrayList() } else sec[cur]?.add(line)
                }
                sec["CPU"]?.firstOrNull()?.let { cpu = parseCpu(it) }
                gpu = sec["GPU"]?.firstOrNull()?.trim()?.split(Regex("\\s+"))?.firstOrNull()?.toIntOrNull()?.takeIf { it in 0..100 }
                if (l == null) note = "MLBB not running (no layer found)"
                else {
                    fps = parseFps(sec["FPS"])
                    note = if (fps != null) "SurfaceFlinger frame timestamps (Shizuku)" else { layer = null; "No frames from MLBB layer" }
                }
            }
        }
        if (tick % 3 == 1) ping = try {
            val t0 = System.nanoTime()
            Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
            ((System.nanoTime() - t0) / 1_000_000).toInt()
        } catch (_: Exception) { null }

        return Snap(fps, note, hz, temp, thermal, cpu, mhz, gpu,
            (mi.totalMem - mi.availMem) / 1048576, mi.availMem / 1048576, mi.totalMem / 1048576, ping)
    }

    private fun findLayer(pkg: String): String? {
        val r = ShizukuBridge.exec("dumpsys SurfaceFlinger --list | grep -F '$pkg'")
        val ls = r.text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        return ls.firstOrNull { it.contains("SurfaceView") } ?: ls.firstOrNull()
    }

    private fun parseCpu(line: String): Int? {
        val p = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (p.size < 5) return null
        val total = p.take(8).sum(); val idle = p[3] + p[4]
        val dt = total - prevTotal; val di = idle - prevIdle
        val had = prevTotal != 0L
        prevTotal = total; prevIdle = idle
        return if (had && dt > 0) (((dt - di) * 100) / dt).toInt().coerceIn(0, 100) else null
    }

    private fun parseFps(lines: List<String>?): Int? {
        if (lines == null || lines.size < 3) return null
        val ts = lines.drop(1).mapNotNull {
            val p = it.trim().split(Regex("\\s+"))
            if (p.size >= 3) p[1].toLongOrNull() else null
        }.filter { it > 0 && it < Long.MAX_VALUE / 2 }
        if (ts.size < 3) return null
        val newest = ts.max()
        val win = ts.filter { newest - it <= 1_000_000_000L }
        if (win.size < 2) return null
        val span = (win.max() - win.min()) / 1e9
        return if (span > 0) Math.round((win.size - 1) / span).toInt() else null
    }
}
