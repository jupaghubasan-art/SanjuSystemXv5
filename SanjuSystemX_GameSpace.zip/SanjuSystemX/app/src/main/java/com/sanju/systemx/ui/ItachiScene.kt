package com.sanju.systemx.ui

import android.content.Context
import android.graphics.*
import kotlin.math.*

/**
 * Original, procedurally drawn Itachi-inspired scene (red moon, ravens, feathers, smoke, Sharingan glow).
 * If you add your own licensed artwork as res/drawable-nodpi/itachi_art.png it is drawn behind the effects.
 */
class ItachiScene(ctx: Context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val art: Bitmap? = run {
        val id = ctx.resources.getIdentifier("itachi_art", "drawable", ctx.packageName)
        if (id != 0) BitmapFactory.decodeResource(ctx.resources, id) else null
    }
    private var sw = 0f; private var sh = 0f
    private var moon: RadialGradient? = null
    private var glow: RadialGradient? = null

    private fun ease(x: Float) = (x.coerceIn(0f, 1f)).let { it * it * (3 - 2 * it) }
    private fun stage(prog: Float, a: Float, b: Float) = ease((prog - a) / (b - a))

    /** [t] seconds for motion, [prog] 0..1 reveal progress (use 1 for the ambient background). */
    fun draw(c: Canvas, w: Float, h: Float, t: Float, prog: Float) {
        if (w != sw || h != sh) {
            sw = w; sh = h
            moon = RadialGradient(w * .28f, h * .42f, h * .28f, intArrayOf(0xFFB5262B.toInt(), 0xFF7A1218.toInt(), 0xFF2A070C.toInt()), floatArrayOf(0f, .75f, 1f), Shader.TileMode.CLAMP)
            glow = RadialGradient(w * .72f, h * .38f, h * .22f, intArrayOf(0x66FF2030, 0x00FF2030), null, Shader.TileMode.CLAMP)
        }
        c.drawColor(0xFF07080D.toInt())
        art?.let {
            p.reset(); p.isFilterBitmap = true; p.alpha = (140 * stage(prog, .25f, .6f)).toInt()
            val s = max(w / it.width, h / it.height)
            c.save(); c.translate((w - it.width * s) / 2, (h - it.height * s) / 2); c.scale(s, s); c.drawBitmap(it, 0f, 0f, p); c.restore()
        }
        // moon
        val ma = stage(prog, 0f, .25f)
        p.reset(); p.isAntiAlias = true; p.shader = moon; p.alpha = (255 * ma).toInt()
        c.drawCircle(w * .28f, h * .42f + sin(t * .4f) * h * .006f, h * .28f, p); p.shader = null
        // smoke
        p.reset(); p.isAntiAlias = true
        for (i in 0 until 3) {
            val x = ((t * (8 + i * 4) + i * w / 3) % (w * 1.4f)) - w * .2f
            p.color = Color.argb((14 * ma).toInt(), 160, 30, 40)
            c.drawCircle(x, h * (.7f + i * .08f), h * (.22f + i * .04f), p)
        }
        // ravens
        val ra = stage(prog, .15f, .45f)
        p.color = Color.argb((235 * ra).toInt(), 6, 6, 10)
        for (i in 0 until 6) {
            val sp = .03f + i * .008f
            val x = (((i * .19f) + t * sp) % 1.3f - .15f) * w
            val y = h * (.15f + .12f * i % .6f) + sin(t * .8f + i) * h * .02f
            val s = h * (.035f + .01f * (i % 3))
            val flap = sin(t * 5f + i * 2f) * s * .6f
            path.reset()
            path.moveTo(x - s, y - flap); path.quadTo(x - s * .5f, y - s * .6f, x, y)
            path.quadTo(x + s * .5f, y - s * .6f, x + s, y - flap)
            path.quadTo(x + s * .4f, y + s * .15f, x, y + s * .3f)
            path.quadTo(x - s * .4f, y + s * .15f, x - s, y - flap)
            c.drawPath(path, p)
        }
        // feathers
        p.color = Color.argb((150 * ra).toInt(), 90, 10, 20)
        for (i in 0 until 9) {
            val x = ((i * .113f + sin(t * .3f + i) * .03f) % 1f) * w
            val y = ((t * (.02f + i * .004f) + i * .17f) % 1.1f - .05f) * h
            c.save(); c.translate(x, y); c.rotate(t * 20f + i * 40f)
            c.drawOval(-h * .012f, -h * .004f, h * .012f, h * .004f, p); c.restore()
        }
        // Sharingan glow
        val sa = stage(prog, .35f, .65f)
        if (sa > 0f) {
            p.reset(); p.isAntiAlias = true; p.shader = glow; p.alpha = (255 * sa * (.8f + .2f * sin(t * 2f))).toInt()
            c.drawCircle(w * .72f, h * .38f, h * .22f, p); p.shader = null
            val cx = w * .72f; val cy = h * .38f; val r = h * .07f
            p.style = Paint.Style.FILL; p.color = Color.argb((255 * sa).toInt(), 200, 20, 35); c.drawCircle(cx, cy, r, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = r * .08f; p.color = Color.argb((255 * sa).toInt(), 20, 0, 5)
            c.drawCircle(cx, cy, r * .62f, p)
            p.style = Paint.Style.FILL
            for (k in 0 until 3) {
                val a = t * .6f + k * 2.0944f
                c.drawCircle(cx + cos(a) * r * .62f, cy + sin(a) * r * .62f, r * .13f, p)
            }
            c.drawCircle(cx, cy, r * .16f, p)
        }
    }
}
